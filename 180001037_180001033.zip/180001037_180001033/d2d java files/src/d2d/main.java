package d2d;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JSlider;
import javax.swing.JSeparator;

public class main extends JFrame {

	private JPanel contentPane;
	private JTextField aeid;
	private JPasswordField aepwd;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main frame = new main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1150 ,950);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnMyProfile = new JButton("My Profile");
		btnMyProfile.addActionListener(new ActionListener()
				{
				public void actionPerformed(ActionEvent arg0)
				{
					
						contentPane.disable();;
						Myprofile myp=new Myprofile();
						myp.setVisible(true);
						
					
				}
				
				});
		btnMyProfile.setBounds(777, 505, 182, 44);
		contentPane.add(btnMyProfile);
		
		JButton btnProductsAvailable = new JButton("Products Available");
		btnProductsAvailable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.disable();;
				Products prod= new Products();
				prod.setVisible(true);
			}
		});
		btnProductsAvailable.setBounds(73, 495, 182, 44);
		contentPane.add(btnProductsAvailable);
		
		JButton btnAdminLogin = new JButton("Admin Login");
		btnAdminLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/d2d","root","Prashant1108@");
					PreparedStatement pst=con.prepareStatement("SELECT * FROM adminl where emailid=? and password=?");
					pst.setString(1, aeid.getText());
					pst.setString(2, aepwd.getText());
					ResultSet rst=pst.executeQuery();
					int count=0;
					while(rst.next())
					{
						count++;
					}
					if(count==1)
					{
						JOptionPane.showMessageDialog(null, "Login Successful");
						contentPane.disable();
						Admin adm= new Admin();
						adm.setVisible(true);
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Login UNSuccessful");
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
		btnAdminLogin.setBounds(443, 330, 171, 37);
		contentPane.add(btnAdminLogin);
		
		JButton btnorders = new JButton("Order Now!");
		btnorders.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.disable();
				Myorders ord= new Myorders();
				ord.setVisible(true);
			}
		});
		btnorders.setBounds(443, 567, 182, 44);
		contentPane.add(btnorders);
		
		aeid = new JTextField();
		aeid.setText("Admin EmailID");
		aeid.setBounds(435, 204, 182, 37);
		contentPane.add(aeid);
		aeid.setColumns(10);
		
		JLabel lblHome = new JLabel("HOME PAGE");
		lblHome.setFont(new Font("FreeSans", Font.BOLD, 40));
		lblHome.setForeground(Color.BLUE);
		lblHome.setBounds(413, 66, 284, 77);
		contentPane.add(lblHome);
		
		JSlider slider = new JSlider();
		slider.setBounds(44, 761, 1032, 16);
		contentPane.add(slider);
		
		aepwd = new JPasswordField();
		aepwd.setText("password");
		aepwd.setBounds(435, 253, 182, 37);
		contentPane.add(aepwd);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(144, 126, 830, 16);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(144, 420, 877, 23);
		contentPane.add(separator_1);
		
		JLabel lblAdminLogin = new JLabel("Admin Login");
		lblAdminLogin.setBounds(471, 154, 162, 23);
		contentPane.add(lblAdminLogin);
	}
}
