package d2d;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import java.awt.Color;

public class Admin extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	private JButton btnAddProducts;
	private JScrollPane scrollPane;
	private JScrollPane scrollPane_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin frame = new Admin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Admin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1150, 950);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(80, 83, 927, 336);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(80, 527, 954, 322);
		contentPane.add(scrollPane_1);
		
		table_1 = new JTable();
		scrollPane_1.setViewportView(table_1);
		
		JButton btnShowUsers = new JButton("SHOW USERS");
		btnShowUsers.setBounds(159, 33, 152, 25);
		btnShowUsers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/d2d","root","Prashant1108@");
					String sl="SELECT * FROM login";
					PreparedStatement ps1 = con.prepareStatement(sl);
					ResultSet rsr= ps1.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rsr));
				}catch(Exception ea) {
					ea.printStackTrace();
				}
			}
		});
		contentPane.add(btnShowUsers);
		
		JButton btnShowEmployees = new JButton("SHOW EMPLOYEES");
		btnShowEmployees.setBounds(240, 476, 196, 25);
		btnShowEmployees.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/d2d","root","Prashant1108@");
					String s1="SELECT * FROM Employees";
					PreparedStatement ps2 = con.prepareStatement(s1);
					ResultSet rsr= ps2.executeQuery();
					table_1.setModel(DbUtils.resultSetToTableModel(rsr));
				}catch(Exception ea) {
					ea.printStackTrace();
				}
			}
		});
		contentPane.add(btnShowEmployees);
		
		JButton btnNewButton = new JButton("ADD EMPLOYEES");
		btnNewButton.setBounds(688, 460, 173, 25);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				try
				{
					contentPane.disable();
					aemployees ae=new aemployees();
					ae.setVisible(true);
				}catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		contentPane.add(btnNewButton);
		
		btnAddProducts = new JButton("ADD PRODUCTS");
		btnAddProducts.setBounds(672, 33, 173, 25);
		btnAddProducts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					contentPane.disable();
					aproducts ae=new aproducts();
					ae.setVisible(true);
				}catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		contentPane.add(btnAddProducts);
	}
}
