package d2d;
import java.sql.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

public class Signup extends JFrame {

	private JPanel contentPane;
	private JTextField id;
	private JTextField username;
	private JPasswordField pwd;
	private JTextField address;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Signup frame = new Signup();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Signup() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegister = new JLabel("Register!!!");
		lblRegister.setBounds(176, 12, 138, 15);
		contentPane.add(lblRegister);
		
		JLabel lblEmailid = new JLabel("EmailID");
		lblEmailid.setBounds(92, 52, 66, 15);
		contentPane.add(lblEmailid);
		
		id = new JTextField();
		id.setBounds(186, 48, 124, 19);
		contentPane.add(id);
		id.setColumns(10);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(102, 79, 66, 15);
		contentPane.add(lblName);
		
		username = new JTextField();
		username.setBounds(190, 79, 124, 19);
		contentPane.add(username);
		username.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(92, 112, 66, 15);
		contentPane.add(lblPassword);
		
		pwd = new JPasswordField();
		pwd.setBounds(186, 110, 129, 19);
		contentPane.add(pwd);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setBounds(92, 139, 66, 15);
		contentPane.add(lblAddress);
		
		address = new JTextField();
		address.setBounds(190, 141, 124, 19);
		contentPane.add(address);
		address.setColumns(10);
		
		JButton btnsignup = new JButton("Sign Up");
		btnsignup.addActionListener(new ActionListener()
				{
				public void actionPerformed(ActionEvent arg0)
				{
					try {
						Class.forName("com.mysql.cj.jdbc.Driver");
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					try {
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/d2d","root","Prashant1108@");
						PreparedStatement ps=con.prepareStatement("INSERT INTO login(emailid,password,name,address) VALUES(?,?,?,?)");
						ps.setString(1, id.getText());
						ps.setString(2, pwd.getText());
						ps.setString(3, username.getText());
						ps.setString(4, address.getText());
						
						ps.execute();
						JOptionPane.showMessageDialog(null, "Registration Successful");
						ps.close();
						con.close();
				}catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}}
				});
		btnsignup.setBounds(156, 199, 114, 25);
		contentPane.add(btnsignup);
	}
}
