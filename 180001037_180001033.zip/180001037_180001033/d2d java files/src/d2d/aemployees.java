package d2d;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class aemployees extends JFrame {

	private JPanel contentPane;
	private JTextField eid;
	private JTextField ename;
	private JTextField esal;
	private JTextField ejid;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					aemployees frame = new aemployees();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public aemployees() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		eid = new JTextField();
		eid.setText("Employee ID");
		eid.setBounds(12, 38, 95, 19);
		contentPane.add(eid);
		eid.setColumns(10);
		
		ename = new JTextField();
		ename.setText("Employee Name");
		ename.setBounds(12, 69, 124, 19);
		contentPane.add(ename);
		ename.setColumns(10);
		
		esal = new JTextField();
		esal.setText("Salary");
		esal.setBounds(12, 129, 124, 19);
		contentPane.add(esal);
		esal.setColumns(10);
		
		ejid = new JTextField();
		ejid.setText("Job ID");
		ejid.setBounds(12, 98, 124, 19);
		contentPane.add(ejid);
		ejid.setColumns(10);
		
		JButton btnAddEmp = new JButton("ADD Emp");
		btnAddEmp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/d2d","root","Prashant1108@");
				PreparedStatement ps=con.prepareStatement("INSERT INTO Employees(Employee_id,Emp_name,Job_id,Salary) VALUES(?,?,?,?)");
				ps.setString(1, eid.getText());
				ps.setString(2, ename.getText());
				ps.setString(3, ejid.getText());
				ps.setString(4, esal.getText());
				
				ps.execute();
				JOptionPane.showMessageDialog(null, "Registration Successful");
				ps.close();
				con.close();
			}catch (SQLException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}}
		});
		btnAddEmp.setBounds(26, 173, 114, 25);
		contentPane.add(btnAddEmp);
		
		JButton btnShowEmp = new JButton("Show Emp");
		btnShowEmp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/d2d","root","Prashant1108@");
					String sl="SELECT * FROM Employees";
					PreparedStatement ps1 = con.prepareStatement(sl);
					ResultSet rsr= ps1.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rsr));
				}catch(Exception ea) {
					ea.printStackTrace();
				}
			}
		});
		btnShowEmp.setBounds(237, 12, 114, 25);
		contentPane.add(btnShowEmp);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(170, 40, 258, 196);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
	}

}
