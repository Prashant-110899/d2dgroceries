package d2d;

import java.awt.EventQueue;
import java.awt.image.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class login {

	private JFrame frame;
	private JTextField id;
	private JPasswordField pass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login window = new login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblLogin = new JLabel("WELCOME!!!D2D GROCERIES");
		lblLogin.setFont(new Font("FreeSans", Font.BOLD, 35));
		lblLogin.setBounds(37, 28, 523, 32);
		frame.getContentPane().add(lblLogin);
		
		JLabel lblEmailid = new JLabel("EmailID");
		lblEmailid.setBounds(386, 120, 66, 15);
		frame.getContentPane().add(lblEmailid);
		
		id = new JTextField();
		id.setBounds(346, 152, 140, 32);
		frame.getContentPane().add(id);
		id.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(386, 209, 66, 15);
		frame.getContentPane().add(lblPassword);
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/d2d","root","Prashant1108@");
					PreparedStatement pst=con.prepareStatement("SELECT * FROM login where emailid=? and password=?");
					pst.setString(1, id.getText());
					pst.setString(2, pass.getText());
					ResultSet rst=pst.executeQuery();
					int count=0;
					while(rst.next())
					{
						count++;
					}
					if(count==1)
					{
						JOptionPane.showMessageDialog(null, "Login Successful");
						frame.dispose();
						main Main=new main();
						Main.setVisible(true);
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Login UNSuccessful");
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnLogin.setBounds(362, 303, 114, 25);
		frame.getContentPane().add(btnLogin);
		
		pass = new JPasswordField();
		pass.setBounds(346, 243, 142, 32);
		frame.getContentPane().add(pass);
		
		JButton btnsignup = new JButton("New User? Sign Up.");
		btnsignup.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent arg0)
					{
						try
						{
							frame.dispose();
							Signup signup=new Signup();
							signup.setVisible(true);
						}catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
		btnsignup.setBounds(193, 397, 174, 25);
		frame.getContentPane().add(btnsignup);
		
		JLabel lblNewLabel = new JLabel("");
		Image img=new ImageIcon(this.getClass().getResource("/ff.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(77, 120, 267, 208);
		frame.getContentPane().add(lblNewLabel);
	}

	public static void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}
}
