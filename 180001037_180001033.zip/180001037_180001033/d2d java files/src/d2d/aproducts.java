package d2d;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class aproducts extends JFrame {

	private JPanel contentPane;
	private JTextField pid;
	private JTextField pname;
	private JTextField pprice;
	private JTable table;
	private JScrollPane scrollPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					aproducts frame = new aproducts();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public aproducts() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		pid = new JTextField();
		pid.setText("Prod ID");
		pid.setBounds(12, 12, 91, 19);
		contentPane.add(pid);
		pid.setColumns(10);
		
		pname = new JTextField();
		pname.setText("Prod Name");
		pname.setBounds(152, 12, 124, 19);
		contentPane.add(pname);
		pname.setColumns(10);
		
		pprice = new JTextField();
		pprice.setText("Price");
		pprice.setBounds(314, 12, 91, 19);
		contentPane.add(pprice);
		pprice.setColumns(10);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/d2d","root","Prashant1108@");
					PreparedStatement ps=con.prepareStatement("INSERT INTO Products(Prod_key,Prod_name,Price) VALUES(?,?,?)");
					ps.setString(1, pid.getText());
					ps.setString(2, pname.getText());
					ps.setString(3, pprice.getText());
	
					
					ps.execute();
					JOptionPane.showMessageDialog(null, "Product added Successfully");
					ps.close();
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnAdd.setBounds(162, 51, 114, 25);
		contentPane.add(btnAdd);
		
		JButton btnShowAvailableProducts = new JButton("SHOW AVAILABLE PRODUCTS");
		btnShowAvailableProducts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/d2d","root","Prashant1108@");
					String sl="SELECT * FROM Products";
					PreparedStatement ps1 = con.prepareStatement(sl);
					ResultSet rsr= ps1.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rsr));
				}catch(Exception ea) {
					ea.printStackTrace();
				}
			}
		});
		btnShowAvailableProducts.setBounds(89, 88, 278, 25);
		contentPane.add(btnShowAvailableProducts);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(39, 128, 376, 111);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
	}

}
