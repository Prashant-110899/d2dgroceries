package d2d;
import java.sql.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class Myorders extends JFrame {

	private JPanel contentPane;
	private JTextField Prod_key;
	private JTextField Prod_name;
	private JTextField Quantity;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Myorders frame = new Myorders();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Myorders() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.disable();
				main back= new main();
				back.setVisible(true);
			}
		});
		btnBack.setBounds(22, 0, 66, 25);
		contentPane.add(btnBack);
		
		JButton btnPlaceOrder = new JButton("Place Order");
		btnPlaceOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/d2d","root","Prashant1108@");
					PreparedStatement ps=con.prepareStatement("INSERT INTO Orders(pkey,pname,quantity) VALUES(?,?,?)");
					ps.setString(1, Prod_key.getText());
					ps.setString(2, Prod_name.getText());
					ps.setString(3, Quantity.getText());
					
					
					ps.execute();
					JOptionPane.showMessageDialog(null, "Orders Placed");
					ps.close();
					con.close();
			}catch (SQLException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
				
			}}
			
			
		});
		btnPlaceOrder.setBounds(306, 68, 114, 25);
		contentPane.add(btnPlaceOrder);
		
		Prod_key = new JTextField();
		Prod_key.setBounds(139, 40, 124, 19);
		contentPane.add(Prod_key);
		Prod_key.setColumns(10);
		
		Prod_name = new JTextField();
		Prod_name.setBounds(149, 71, 124, 19);
		contentPane.add(Prod_name);
		Prod_name.setColumns(10);
		
		Quantity = new JTextField();
		Quantity.setBounds(139, 102, 124, 19);
		contentPane.add(Quantity);
		Quantity.setColumns(10);
		
		JLabel lblProductKey = new JLabel("Product Key");
		lblProductKey.setBounds(22, 37, 114, 25);
		contentPane.add(lblProductKey);
		
		JLabel lblProductName = new JLabel("Product Name");
		lblProductName.setBounds(12, 59, 111, 43);
		contentPane.add(lblProductName);
		
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setBounds(22, 102, 66, 15);
		contentPane.add(lblQuantity);
		
		JButton btnshow = new JButton("SHOW ORDERS");
		btnshow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/d2d","root","Prashant1108@");
					String sl="SELECT * FROM Orders";
					PreparedStatement ps1 = con.prepareStatement(sl);
					ResultSet rsr= ps1.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rsr));
				}catch(Exception ea) {
					ea.printStackTrace();
				}
			}
		});
		btnshow.setBounds(111, 133, 199, 25);
		contentPane.add(btnshow);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(34, 169, 391, 89);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
	}

}
