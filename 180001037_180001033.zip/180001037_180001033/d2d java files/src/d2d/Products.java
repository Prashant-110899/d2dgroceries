package d2d;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Products extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Products frame = new Products();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Products() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1150, 950);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblProductsAvailable = new JLabel("Products Available");
		lblProductsAvailable.setFont(new Font("Dialog", Font.BOLD, 20));
		lblProductsAvailable.setBounds(440, 145, 213, 15);
		contentPane.add(lblProductsAvailable);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(126, 203, 891, 567);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnShowProducts = new JButton("SHOW PRODUCTS");
		btnShowProducts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/d2d","root","Prashant1108@");
					String sl="SELECT * FROM Products";
					PreparedStatement ps1 = con.prepareStatement(sl);
					ResultSet rsr= ps1.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rsr));
				}catch(Exception ea) {
					ea.printStackTrace();
				}
			}
		});
		btnShowProducts.setBounds(698, 34, 328, 73);
		contentPane.add(btnShowProducts);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.disable();
				main back = new main();
				back.setVisible(true);
			}
		});
		btnBack.setBounds(121, 34, 201, 73);
		contentPane.add(btnBack);
	}
}
